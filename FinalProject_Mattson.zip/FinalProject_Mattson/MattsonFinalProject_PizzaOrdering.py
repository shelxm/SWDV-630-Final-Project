#Sheldon Mattson
#MattsonFinalProject_PizzaOrdering.py

#class to create Pizza shops- add to and remove from in progress and completed order lists, estimate time for order
class Shop:
    def __init__(self, coName, address, phoneNum):
        self.coName=coName
        self.address=address
        self.phoneNum=phoneNum
        self.ordersInProgress=[]
        self.ordersCompleted=[]
    def estimateTime(self, obj):
        if len(obj.orderContents)<8:
            return 'Your order will be ready in about 15 minutes'
        else:
            return 'Your order will be ready in 25-30 minutes'
    def orderInProgress(self, obj):
        self.ordersInProgress.append(obj)
        return self.estimateTime(obj)
    def completeOrder(self, obj):
        self.ordersInProgress.remove(obj)
        self.ordersCompleted.append(obj)
        return f'Order #{obj.orderNum} has been completed. Thank you for your order.'
#customer object class
class Customer:
    def __init__(self, fName, lName, address, phoneNum):
        self.fName=fName
        self.lName=lName
        self.address=address
        self.phoneNum=phoneNum
        self.orders=[]
#allows for printing of list contents
    def __iter__(self):
        return self
    def __next__(self):
        self.index=0
        if self.index >= len(self.orderContents):
            self.index=-1
            raise StopIteration
        else:
            return self.orderContents[self.index]
#Allow for input of customer object attributes
    @classmethod
    def getCustomerInfo(self):
        while 1:
            try:
                fName=input('Enter your first name: ')
                lName=input('Enter your last name: ')
                address=input('Enter your address: ')
                phoneNum=input('Enter your phone number: ')
            except:
                print('Invalid input. Please try again.')
                continue
    def getOrders(self):
        print(f'Orders for {self.fName}: ')
        for obj in self.orders:
            print(f'{obj.orderNum}')
    def submitOrder(self, obj):
        self.orders.append(obj)
        return 'Your order has been submitted'
#Order object class- add to order, remove from order, retrieiving order contents
class Order:
    def __init__(self, orderNum):
        self.orderNum=orderNum
        self.orderContents=[]
        self.orderTotal=0
#a]Allows for printing of list contents
    def __iter__(self):
        return self
    def __next__(self):
        self.index=0
        if self.index >= len(self.orderContents):
            self.index=-1
            raise StopIteration
        else:
            return self.orderContents[self.index]
    def addToOrder(self, obj):
        self.orderContents.append(obj)
        self.orderTotal+=obj.price
        return f'{obj.name} has been added to Order #{self.orderNum}. Your current order total is ${self.orderTotal:.2f}'
    def removeFromOrder(self, obj):
        if obj in self.orderContents:
            self.orderContents.remove(obj)
            self.orderTotal-=obj.price
            return f'{obj.name} has been removed from your order. Your new order total is ${self.orderTotal:.2f}'
        else:
            return f'{obj} was not found in your order.'
    def getCurrentOrder(self):
        for obj in self.orderContents:
            print(f'{obj.name} | {obj.price}')
        return f'Total: ${self.orderTotal:.2f}'
#Pizza object class- can add toppings if desired, change size, and change crust type
class Pizza:
    def __init__(self, name, size, crust, price, description):
        self.name=name
        self.size=size
        self.crust=crust
        self.price=price
        self.description=description
        self.toppings=[]
    def addTopping(self, item, price):
        self.toppings.append(item)
        self.price+=price
    def changeSize(self, size):
        self.size=size
        return f'Your {self.name} pizza size has been changed to a {self.size}'
    def changeCrust(self, crust):
        self.crust=crust
        return 'Your {self.name} pizza crust has been changed to {self.crust}'
#Breadstick object class- can add and remove cheese to breadsticks with approrpiate charge
class Breadstick:
    def __init__(self, name, count, price):
        self.name=name
        self.count=count
        self.price=price
    def addCheese(self):
        self.price+=1.00
        self.name='Cheese breadstick'
        return 'Cheese breadstick'
    def removeCheese(self):
        self.price-=1.00
        return 'Cheese has been removed from your breadstick order.'
#Drink object class- can check if drink is sugar free or not
class Drink:
    def __init__(self, name, size, price, brand, sugar):
        self.name=name
        self.size=size
        self.price=price
        self.brand=brand
        self.sugar=sugar
    def sugarFree(self):
        if self.sugar=='F':
            return f"{self.brand}'s {self.name} is sugar free."
        else:
            return f"{self.brand}'s {self.name} contains sugar."

#test of class methods
def main():
    pShop=Shop('Elementary Pizza', '221B Baker St', '867-5309')
    c1=Customer('Jean Luc', 'Picard', 'Château Picard', '123-4567')
    d1=Drink('Root beer', 'M', 2.99, 'Mug', 'Y')
    print(d1.sugarFree())
    b1=Breadstick('Breadstick', 6, 7.99)
    p1=Pizza('Meat lovers', 'M', 'Whole wheat', 13.99, 'Meat lovers is made of pepperoni, sausage, ham, and bacon.')
    print(p1.changeSize('L'))
    print(b1.addCheese())
    o1=Order(1234)
    print(o1.addToOrder(p1))
    print(o1.addToOrder(b1))
    print(o1.addToOrder(d1))
    print(o1.removeFromOrder(b1))
    print(o1.getCurrentOrder())
    print(c1.submitOrder(o1))
    c1.getOrders()
    print(c1.submitOrder(o1))
    print(pShop.orderInProgress(o1))
    print(pShop.completeOrder(o1))
main()